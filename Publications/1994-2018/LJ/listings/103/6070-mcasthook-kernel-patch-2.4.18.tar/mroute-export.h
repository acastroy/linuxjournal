


extern  struct vif_device vif_table[MAXVIFS];		/* Devices 		*/
extern  int maxvif;


