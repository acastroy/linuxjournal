int main() 
{   int i;
    for(i = 0;i < 10; ++i) {
        printf("My counter: %d \n", i);
        sleep(2);
    }
    return 0;
}
