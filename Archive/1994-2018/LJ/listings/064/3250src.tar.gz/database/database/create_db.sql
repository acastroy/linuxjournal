use master
go

print "Creating the database book_d"
go

create database book_d on device01 = 20 log on device02 = 10
go

