use book_d
go

print "Adding the user store_user to the database book_d"
go

sp_adduser store_user
go

