print "Adding the user store_user"
go

sp_addlogin 'store_user','a&emtvvh1tnt'
go

